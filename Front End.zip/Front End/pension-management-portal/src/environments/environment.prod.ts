export const environment = {
  production: true
};

// export const baseUrlAuth =    'http://localhost:8400/auth/api/v1/';
// export const baseUrlDetails = 'http://localhost:8200/pensioner/api/v1/';
// export const baseUrlProcess = 'http://localhost:8100/process/api/v1/';



export const baseUrlAuth =    'http://authpms839214-env.eba-mbpwkeeh.us-east-1.elasticbeanstalk.com/auth/api/v1/';
export const baseUrlDetails = 'http://pension-details.us-east-1.elasticbeanstalk.com/pensioner/api/v1/';
export const baseUrlProcess = 'http://process-pension.us-east-1.elasticbeanstalk.com/process/api/v1/';

